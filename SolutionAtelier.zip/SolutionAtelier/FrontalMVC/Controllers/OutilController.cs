﻿using FrontalMVC.Models.Perso;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;

namespace FrontalMVC.Controllers
{
    public class OutilController : Controller
    {
        private IGenerateur _generateur;
        public OutilController(IGenerateur generateur) {
            _generateur = generateur;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Generation()
        {
            var serie = _generateur.Generer(10);
            return View(serie);
        }

        public IActionResult ResteJours()
        {

            DateTime DateDuJour = DateTime.Now;
            DateTime DateFinFormation = new DateTime(2024, 03, 15);
            int NbJoursRestants = DateFinFormation.Subtract(DateDuJour).Days;
            return View(NbJoursRestants);
        }
    }
}
