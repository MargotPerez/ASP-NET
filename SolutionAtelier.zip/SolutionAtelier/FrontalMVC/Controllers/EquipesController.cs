﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FrontalMVC.Models.EF;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.AspNetCore.Authorization;

namespace FrontalMVC.Controllers
{
    public class EquipesController : Controller
    {
        private readonly TeamContext _context;


        //public IActionResult TrouverEquipeLeader()
        public PartialViewResult TrouverEquipeLeader()
        {
            var leader = _context.Equipes.OrderByDescending(m=> m.MaxMembres).First();

            return PartialView("_FicheEquipe", leader);
        }

        public EquipesController(TeamContext context)
        {
            _context = context;
        }

        // GET: Equipes
        //[OutputCache(Duration =30)]
        //[Authorize]
        public async Task<IActionResult> Index()
        {
            return View(await _context.Equipes.ToListAsync());
        }

        // GET: Equipes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var dtHorodatage = DateTime.Now.ToLongTimeString();
            string strHorodatage = $"Détails demandés à : {dtHorodatage}";

            // transfert de la chaine strHorodatage vers la vue :
           // ViewData["Horodatage"] = strHorodatage;
           ViewBag.Horo = dtHorodatage;

            if (id == null)
            {
                return NotFound();
            }

            //var equipe = await _context.Equipes
            //    .FirstOrDefaultAsync(m => m.ID == id);

            var equipe = await _context.Equipes.Include("Joueurs")
               .FirstOrDefaultAsync(m => m.ID == id);

            if (equipe == null)
            {
                return NotFound();
            }

            return View(equipe);
        }

        // GET: Equipes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Equipes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Nom,MaxMembres")] Equipe equipe)
        //public async Task<IActionResult> Create(MvcForm form)    => On ferait comme ça si on voulait personnaliser la correspondance tra form et classe 
        {
            //Equipe equipe = new Equipe();

            //equipe.ID = form["ID"];

            if (ModelState.IsValid)
            {
                _context.Add(equipe);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(equipe);
        }

        // GET: Equipes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var equipe = await _context.Equipes.FindAsync(id);
            if (equipe == null)
            {
                return NotFound();
            }
            return View(equipe);
        }

        // POST: Equipes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Nom,MaxMembres")] Equipe equipe)
        {
            if (id != equipe.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(equipe);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EquipeExists(equipe.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                   return RedirectToAction(nameof(Index)); //=> une méthode appelle vers l'autre méthode 
              //  return View("Index"); => marche pas, la vue attend un modèle (pas asso à la méthode voulue)
            }
            return View(equipe);
        }

        // GET: Equipes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var equipe = await _context.Equipes
                .FirstOrDefaultAsync(m => m.ID == id);
            if (equipe == null)
            {
                return NotFound();
            }

            return View(equipe);
        }

        // POST: Equipes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var equipe = await _context.Equipes.FindAsync(id);
            if (equipe != null)
            {
                _context.Equipes.Remove(equipe);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EquipeExists(int id)
        {
            return _context.Equipes.Any(e => e.ID == id);
        }
    }
}
