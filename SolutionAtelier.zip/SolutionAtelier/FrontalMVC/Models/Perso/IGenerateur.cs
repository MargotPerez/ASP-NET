﻿
namespace FrontalMVC.Models.Perso
{
    public interface IGenerateur
    {
        List<int> Generer(int nombre);
    }
}